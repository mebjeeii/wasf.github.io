---
name: New Issue, Bug report, Question
about: New Issue, Bug report, Question
title: ''
labels: ''
assignees: ''

---

## State your operating system:
Windows/Mac/Linux. in case of linux, whether you use CLI, gtk2, or gtk3 version.

## DesMuME version
e.g. 0.9.13 or git master

## Isse
type here what's bothering you, in a detailed manner.


